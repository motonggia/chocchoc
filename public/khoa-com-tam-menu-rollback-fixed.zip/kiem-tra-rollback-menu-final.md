# Kiểm tra bản sửa menu sau khi khôi phục mốc trước khi bỏ nút

## Phạm vi sửa

Website được khôi phục từ `khoa-com-tam-navbar-compact.zip`, là bản ngay trước thay đổi bỏ nút Đăng ký tư vấn. Sau đó chỉ thực hiện các thay đổi tối thiểu: xóa CTA riêng trong header desktop/mobile, đổi mục Liên hệ thành Đăng ký trỏ đến `thu-ngo.html#dang-ky-tu-van`, đồng bộ 8 mục menu desktop/mobile và dùng một logic active duy nhất.

## Kiểm tra tĩnh

- 12 trang HTML.
- 24 menu desktop/mobile.
- Nhãn và href của 8 mục menu khớp nhau trên toàn bộ trang.
- Không còn CTA `Đăng ký tư vấn` trong header hoặc mobile drawer.
- CTA `Đăng ký tư vấn` trong nội dung khóa học/cửa hàng vẫn được giữ lại.
- Mỗi menu tĩnh có đúng một mục active.
- Mỗi trang chỉ có một script xử lý active.
- Kết quả: `PASS`, 0 lỗi.

## Kiểm tra bằng trình duyệt trên cổng xem trước 8001

- Trang chủ: `TRANG CHỦ` active duy nhất ở desktop/mobile; đủ 8 mục; không còn CTA riêng.
- Bấm `KHOÁ HỌC`: URL chuyển đến `index.html#khoa-hoc`; desktop/mobile đều active `KHOÁ HỌC`.
- Bấm `CỬA HÀNG`: mở `cua-hang.html`; desktop/mobile đều active `CỬA HÀNG`.
- Trang Cơm Tấm: desktop/mobile đều active `KHOÁ HỌC`; hai CTA trong nội dung vẫn tồn tại.
- Trang Thư ngỏ tại `#dang-ky-tu-van`: desktop/mobile active `THƯ NGỎ` theo trạng thái trang; mục `ĐĂNG KÝ` trỏ đúng đến `thu-ngo.html#dang-ky-tu-van`; biểu mẫu tồn tại.

## Ghi chú

Không sử dụng các bản `menu-rebuilt`, `ultimate`, `exhaustively-verified` hoặc các bản đã tích lũy nhiều lớp CSS/JavaScript. Bản bàn giao phải được tạo từ mốc khôi phục và thay đổi tối thiểu này.
