# Kiểm tra sâu lỗi menu

## Quan sát thực tế trên bản xem trước

DOM của menu desktop có đủ 8 liên kết, theo thứ tự: Trang chủ, Thư ngỏ, Khoá học, Cửa hàng, Về chúng tôi, Hình ảnh, Hỏi đáp và Đăng ký. Vùng click của từng liên kết được đo riêng, không bị chồng lấn; `elementFromPoint` tại tâm từng liên kết trả về đúng chính thẻ `<a>` tương ứng.

Tại viewport xem trước, menu có độ rộng khoảng 706px và toàn bộ liên kết nằm trong thanh navbar. Lỗi cấu trúc trước đó đã được xử lý bằng cách bổ sung dấu `|` thực vào tất cả thẻ `.sep`, chuẩn hóa href và thêm CSS `flex-wrap: nowrap`, `pointer-events: none` cho dấu phân cách, `display: inline-block` và `z-index` cho thẻ `<a>`.

## Kiểm tra thao tác

Thao tác bấm **KHOÁ HỌC** từ trang chủ đã chuyển đúng đến `index.html#khoa-hoc` và cuộn đúng vùng Danh mục khóa học. Kiểm tra tĩnh trước đó cũng xác nhận 24 menu desktop/mobile có 0 lỗi liên kết.

## Bản sửa mạnh hơn

Đã loại bỏ hoàn toàn các thẻ `<li class="sep">` khỏi DOM của cả menu desktop và mobile. Dấu `|` hiện được vẽ bằng pseudo-element CSS, có `pointer-events: none`, còn mỗi mục menu chỉ còn một thẻ `<li>` chứa một thẻ `<a>` độc lập. Kết quả đo lại: 8 mục menu có vùng click độc lập, không chồng lấn; bấm **Cửa hàng** từ Trang chủ đã mở đúng `cua-hang.html`.

## Kiểm tra các mục sau Cửa hàng

Bấm **Về chúng tôi** từ trang Cửa hàng đã mở đúng `index.html#gioi-thieu`. Tiếp tục bấm **Hình ảnh** đã mở đúng `index.html#hinh-anh-trung-tam` và cuộn đến khu vực Hình ảnh thật tại trung tâm. Hai mục sau Cửa hàng đều nhận click và chuyển đúng đích trong bản xem trước.

Bấm **Hỏi đáp** đã mở đúng `index.html#hoi-dap`; bấm **Đăng ký** đã mở đúng `thu-ngo.html#dang-ky-tu-van` và cuộn thẳng đến biểu mẫu Nhận thông tin khóa học. Như vậy toàn bộ nhóm mục từ **Cửa hàng** trở đi đã được thử trực tiếp trong trình duyệt xem trước.

## Bản menu cuối cùng

Đã loại bỏ hoàn toàn cả thẻ `li.menu-separator` và thẻ `li.sep`. Menu hiện chỉ gồm 8 `<li>` chứa 8 thẻ `<a>` độc lập. Dấu phân cách trực quan hiện là đường viền phải của mỗi mục, không tạo vùng click riêng.

Trên trang `khoa-com-tam.html`, kết quả đo vùng click là: Trang chủ [203–292], Thư ngỏ [302–373], Khoá học [383–465], Cửa hàng [475–556], Về chúng tôi [566–672], Hình ảnh [682–761], Hỏi đáp [771–838], Đăng ký [848–917]. Tại tâm của từng vùng, phần tử nhận click đúng là thẻ `<a>` tương ứng. Số phần tử phân cách trong menu desktop là 0.
