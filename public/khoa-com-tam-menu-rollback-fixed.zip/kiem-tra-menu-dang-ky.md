# Kiểm tra menu Đăng ký

## Kết quả

Trang chủ hiển thị đúng các mục menu mới: Trang chủ, Thư ngỏ, Khoá học, Cửa hàng, Về chúng tôi, Hình ảnh, Hỏi đáp và **Đăng ký**. Nút riêng **Đăng ký tư vấn** ở khu vực bên phải header đã được loại bỏ.

Mục **Đăng ký** trên desktop và mobile đều trỏ đến `thu-ngo.html#dang-ky-tu-van`. Khi kiểm tra bằng trình duyệt, liên kết mở đúng trang Thư Ngỏ và đưa vị trí xem thẳng đến phần **Nhận thông tin khóa học**, nơi có trường Họ và tên, Số điện thoại, 7 lựa chọn nội dung quan tâm và nút Gửi thông tin.

Không còn nhãn `Liên hệ` trong menu chính. Phần Liên hệ ở footer vẫn được giữ nguyên như một khu vực thông tin liên lạc, không bị đổi tên theo yêu cầu chỉ áp dụng cho menu.
